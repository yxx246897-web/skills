---
name: ima-folder-organizer-v2
description: >
  Organize content inside IMA (ima.qq.com) knowledge bases. Create folders,
  move items between folders, batch-import GitHub repos / web URLs into specific
  folders. Use this skill whenever the user wants to put web links, GitHub repos,
  articles, or any media into an organized folder structure inside IMA knowledge
  bases (personal or shared). Triggers: "放进我资料库", "放到某个文件夹", "建个文件夹",
  "把这些链接按主题分一下", "批量导入到 IMA", "挪到XX文件夹里".
agent_created: true
---

# IMA Folder Organizer

## Overview

Organize content inside IMA (ima.qq.com) knowledge bases with proper folder structure. The official `ima-skill` covers basic read/write operations, but **does NOT document the `create_folder` endpoint**, which is essential for organizing anything. This skill fills that gap: it documents the full folder-management workflow (create folder → search/verify → batch import into folder) and the credentials setup.

## Key Discovery (the gap this skill fills)

The official `ima-skill:knowledge-base` documents these endpoints only:
- `search_knowledge_base` / `get_knowledge_base` (find kb)
- `get_knowledge_list` / `search_knowledge` (browse)
- `import_urls` (add web URLs — supports `folder_id` param)
- `add_knowledge` (add file/folder — supports `folder_id` param)
- `check_repeated_names` / `create_media` / COS upload (file uploads)

**Missing from docs but ACTUALLY available**: `create_folder` endpoint for creating new folders.

```bash
# Create folder (undocumented endpoint)
POST /openapi/wiki/v1/create_folder
body: { "knowledge_base_id": "<kb_id>", "name": "<folder_name>" }
returns: { "media_id": "folder_xxxxx" }  ← use this as folder_id
```

Use `create_folder` to get a `folder_id`, then pass it to `import_urls` / `add_knowledge` as the `folder_id` field.

## Credentials Setup

This skill uses the same `ima-skill` credentials. Set these env vars before invoking:

```bash
export IMA_CLIENT_ID="<your client_id>"
export IMA_API_KEY="<your api_key>"
```

Or place them in `~/.config/ima/` (auto-loaded by `ima-skill`).

The ima_api helper is at `~/.workbuddy/skills/ima-skill/ima_api.cjs`:

```bash
node ~/.workbuddy/skills/ima-skill/ima_api.cjs "<api_path>" "<json_body>"
```

## Core Workflow: organize content into folders

### 1. Find the target knowledge base

```bash
node ima_api.cjs "openapi/wiki/v1/search_knowledge_base" '{"query":"<kb_name>","cursor":"","limit":20}'
```

Returns `info_list[].kb_id` and `kb_name`. Note `kb_id` for the next steps.

> **Important**: Do NOT confuse `kb_id` with `folder_id`. A knowledge base's `folder_id` for its root is the `kb_id` itself (per official docs).

### 2. Create the target folder (using undocumented endpoint)

```bash
node ima_api.cjs "openapi/wiki/v1/create_folder" "{\"knowledge_base_id\":\"<kb_id>\",\"name\":\"<folder_name>\"}"
```

Response:
```json
{ "code": 0, "data": { "media_id": "folder_7476584516710174" } }
```

The `media_id` (starting with `folder_`) is the `folder_id` for use in subsequent calls.

**Limits / behavior discovered**:
- Folder names support Chinese
- `ret_code: 0` = success; `222000` = folder not exist (when verifying with bad id)
- No documented limit on folder nesting, but IMA client UI may show only 2 levels by default
- **`create_folder` 接受 `folder_id` 入参，可建嵌套子文件夹**（验证过：建 "01_模型训练" 时传 `folder_id=<上层文件夹id>`，返回的新 media_id 就是子文件夹 id）

### 2b. Create a NESTED sub-folder (2 levels deep)

```bash
node ima_api.cjs "openapi/wiki/v1/create_folder" "{
  \"knowledge_base_id\":\"<kb_id>\",
  \"folder_id\":\"<parent_folder_id>\",
  \"name\":\"<sub_folder_name>\"
}"
```

The returned `media_id` is the nested folder's id — pass it to `import_urls` the same way.

### 3. Batch-import URLs into the folder

```bash
node ima_api.cjs "openapi/wiki/v1/import_urls" "{
  \"knowledge_base_id\":\"<kb_id>\",
  \"folder_id\":\"<folder_id_from_step_2>\",
  \"urls\":[\"https://...\",\"https://...\"]
}"
```

Up to 10 URLs per call, mix of GitHub repos / web articles / WeChat mp.weixin.qq.com URLs.

### 4. Verify the folder contents

```bash
node ima_api.cjs "openapi/wiki/v1/get_knowledge_list" "{
  \"knowledge_base_id\":\"<kb_id>\",
  \"folder_id\":\"<folder_id>\",
  \"cursor\":\"\",
  \"limit\":50
}"
```

Returns `knowledge_list[]` of items inside the folder. Title and media_id for each.

## Common Tasks

### A. Import a list of GitHub repos into a topic folder

```bash
# 1. Find/create folder
FOLDER_ID=$(node ima_api.cjs "openapi/wiki/v1/create_folder" "{\"knowledge_base_id\":\"$KB_ID\",\"name\":\"GitHub精选\"}" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['data']['media_id'])")

# 2. Batch import
node ima_api.cjs "openapi/wiki/v1/import_urls" "{
  \"knowledge_base_id\":\"$KB_ID\",
  \"folder_id\":\"$FOLDER_ID\",
  \"urls\":$(echo "$REPO_URLS" | python3 -c "import json,sys; print(json.dumps(sys.stdin.read().split()))")
}"
```

### B. Move existing items into a folder

`import_urls` adds new items; it does NOT move existing ones. To re-organize already-imported items, the user must do it in the IMA desktop client (drag-and-drop). The OpenAPI does NOT expose a `move_knowledge` endpoint as of 2026-06.

**Workaround for bulk re-organization**:
1. Delete the original items via IMA client
2. Re-import them with the correct `folder_id` via this skill

Or: just create the folder and import new items going forward; let old items stay at root.

### C. Find a folder by name (locate existing folder)

```bash
# Method 1: search
node ima_api.cjs "openapi/wiki/v1/search_knowledge" "{
  \"query\":\"<folder_name>\",
  \"knowledge_base_id\":\"<kb_id>\",
  \"cursor\":\"\"
}"
# Look for items with no `media_id` ending — folders show up too
```

```bash
# Method 2: browse
node ima_api.cjs "openapi/wiki/v1/get_knowledge_list" "{
  \"knowledge_base_id\":\"<kb_id>\",
  \"cursor\":\"\",
  \"limit\":50
}"
# Folders appear in knowledge_list as items with media_id starting "folder_"
```

## Validation Checklist

After organizing, verify with these 3 checks:

1. **Folder exists**: `get_knowledge_list` at root returns the new folder
2. **Folder has content**: `get_knowledge_list` with `folder_id=<new_folder>` returns the imported items
3. **Items are correctly categorized**: titles match what was imported

## API Reference Summary

| Endpoint | Method | Purpose |
|---|---|---|
| `search_knowledge_base` | POST | Find knowledge base by name |
| `create_folder` | POST | **Create new folder (undocumented in official skill)** |
| `import_urls` | POST | Add web URLs (1-10) to kb or folder |
| `get_knowledge_list` | POST | Browse items in kb root or folder |
| `search_knowledge` | POST | Search items by keyword |

## Related Skills

- `ima-skill:knowledge-base` — official read/write operations (browse, search, file upload, note import). Use this skill alongside it.

## Known Issues / Edge Cases

- **`create_folder` is not in official docs** but works. If a future IMA API version breaks it, fallback: use `import_urls` to a non-existent folder and check the error to detect valid folder ids.
- **No `move_knowledge` endpoint**: bulk re-organization requires client-side drag-drop.
- **Folder name conflicts**: silently allowed (multiple folders with same name can coexist).
- **media_id format**: folders start with `folder_`, files with `weburl_` / `media_` / `note_` / etc. — useful for distinguishing in mixed lists.
