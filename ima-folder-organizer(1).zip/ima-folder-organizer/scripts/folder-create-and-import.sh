#!/usr/bin/env bash
# ima-folder-organizer helper
# Usage:
#   ./folder-create-and-import.sh "<kb_id>" "<folder_name>" <url1> [url2 ...]
# 一行完成：建文件夹 + 批量入链接
set -e

KB_ID="$1"
FOLDER_NAME="$2"
shift 2

if [ -z "$KB_ID" ] || [ -z "$FOLDER_NAME" ] || [ -z "$1" ]; then
  echo "Usage: $0 <kb_id> <folder_name> <url1> [url2 ...]" >&2
  exit 1
fi

if [ -z "$IMA_CLIENT_ID" ] || [ -z "$IMA_API_KEY" ]; then
  echo "ERROR: IMA_CLIENT_ID and IMA_API_KEY must be set" >&2
  exit 2
fi

DIR=$(dirname "$0")

# Step 1: create folder
echo "==> Creating folder '$FOLDER_NAME' in kb $KB_ID ..."
CREATE_RES=$("$DIR/folder-create.sh" "$KB_ID" "$FOLDER_NAME")
echo "$CREATE_RES"

FOLDER_ID=$(echo "$CREATE_RES" | python3 -c "import json,sys; print(json.loads(sys.stdin.read())['data']['media_id'])")
echo "==> folder_id = $FOLDER_ID"

# Step 2: import URLs
echo "==> Importing $# URL(s) ..."
"$DIR/folder-import.sh" "$KB_ID" "$FOLDER_ID" "$@"
