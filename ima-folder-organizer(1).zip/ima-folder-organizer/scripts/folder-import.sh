#!/usr/bin/env bash
# ima-folder-organizer helper
# Usage:
#   ./ima-folder-import.sh "<kb_id>" "<folder_id>" "<url1> [<url2> ...]"
# Or with no folder_id (root): pass empty string
#   ./ima-folder-import.sh "<kb_id>" "" "<url1> [<url2> ...]"
set -e

KB_ID="$1"
FOLDER_ID="$2"
shift 2

if [ -z "$KB_ID" ] || [ -z "$1" ]; then
  echo "Usage: $0 <kb_id> <folder_id_or_empty> <url1> [url2 ...]" >&2
  exit 1
fi

# Build URL array JSON
URLS_JSON=$(python3 -c "import json,sys; print(json.dumps(sys.argv[1:]))" "$@")

# Build body
if [ -n "$FOLDER_ID" ]; then
  BODY=$(python3 -c "import json,sys; print(json.dumps({'knowledge_base_id': sys.argv[1], 'folder_id': sys.argv[2], 'urls': json.loads(sys.argv[3])}))" "$KB_ID" "$FOLDER_ID" "$URLS_JSON")
else
  BODY=$(python3 -c "import json,sys; print(json.dumps({'knowledge_base_id': sys.argv[1], 'urls': json.loads(sys.argv[2])}))" "$KB_ID" "$URLS_JSON")
fi

# Verify env
if [ -z "$IMA_CLIENT_ID" ] || [ -z "$IMA_API_KEY" ]; then
  echo "ERROR: IMA_CLIENT_ID and IMA_API_KEY must be set" >&2
  exit 2
fi

node ~/.workbuddy/skills/ima-skill/ima_api.cjs "openapi/wiki/v1/import_urls" "$BODY"
