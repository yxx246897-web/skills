#!/usr/bin/env bash
# ima-folder-organizer helper
# Usage:
#   ./folder-create.sh "<kb_id>" "<folder_name>"
set -e

KB_ID="$1"
FOLDER_NAME="$2"

if [ -z "$KB_ID" ] || [ -z "$FOLDER_NAME" ]; then
  echo "Usage: $0 <kb_id> <folder_name>" >&2
  exit 1
fi

if [ -z "$IMA_CLIENT_ID" ] || [ -z "$IMA_API_KEY" ]; then
  echo "ERROR: IMA_CLIENT_ID and IMA_API_KEY must be set" >&2
  exit 2
fi

BODY=$(python3 -c "import json,sys; print(json.dumps({'knowledge_base_id': sys.argv[1], 'name': sys.argv[2]}))" "$KB_ID" "$FOLDER_NAME")

node ~/.workbuddy/skills/ima-skill/ima_api.cjs "openapi/wiki/v1/create_folder" "$BODY"
